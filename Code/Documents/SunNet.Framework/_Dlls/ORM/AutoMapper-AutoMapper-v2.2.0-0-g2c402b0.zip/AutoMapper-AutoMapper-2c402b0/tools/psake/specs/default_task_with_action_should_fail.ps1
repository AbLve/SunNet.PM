task default {
   "Starting to do stuff..."
   "Adding stuff... 1 + 1 =" + (1+1)
   "Stuff done!"
}