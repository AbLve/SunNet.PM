namespace AutoMapper
{
    public enum MemberList
    {
        Destination = 0,
        Source = 1
    }
}