namespace AutoMapper.Configuration
{
    public class TypeMapConfiguration
    {
        
    }
}