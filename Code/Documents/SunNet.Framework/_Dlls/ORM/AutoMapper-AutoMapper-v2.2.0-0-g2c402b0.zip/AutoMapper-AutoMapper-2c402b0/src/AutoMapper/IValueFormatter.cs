namespace AutoMapper
{
	public interface IValueFormatter
	{
		string FormatValue(ResolutionContext context);
	}

}