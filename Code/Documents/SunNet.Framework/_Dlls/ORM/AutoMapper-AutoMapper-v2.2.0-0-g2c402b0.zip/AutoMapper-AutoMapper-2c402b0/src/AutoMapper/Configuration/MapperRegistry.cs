using System;

namespace AutoMapper.Configuration
{
    public class MapperRegistry
    {
        public void CreateMap<TSource, TDestination>()
        {
        }
    }
}